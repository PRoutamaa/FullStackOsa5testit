import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9924978"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = (props) => {
  if (props.title) {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("p", { children: [
      "A new blog ",
      props.title,
      " by ",
      props.author,
      " was created"
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Notification.jsx",
      lineNumber: 4,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Notification.jsx",
      lineNumber: 3,
      columnNumber: 12
    }, this);
  }
  return null;
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR00sbUJBQ0UsY0FERjtBQUhOLE9BQU1BLG9CQUFxQjtBQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUM5QixNQUFJQyxNQUFNQyxPQUFPO0FBQ2YsV0FDRSxtQ0FDRSxpQ0FBQyxPQUFFO0FBQUE7QUFBQSxNQUFZRCxNQUFNQztBQUFBQSxNQUFNO0FBQUEsTUFBS0QsTUFBTUU7QUFBQUEsTUFBTztBQUFBLFNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUNBLFNBQVE7QUFDVjtBQUFDQyxLQVRLSjtBQVdOLGVBQWVBO0FBQVksSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5vdGlmaWNhdGlvbiIsInByb3BzIiwidGl0bGUiLCJhdXRob3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTm90aWZpY2F0aW9uID0gKHByb3BzKSA9PiB7XG4gIGlmIChwcm9wcy50aXRsZSkge1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8cD5BIG5ldyBibG9nIHtwcm9wcy50aXRsZX0gYnkge3Byb3BzLmF1dGhvcn0gd2FzIGNyZWF0ZWQ8L3A+XG4gICAgICA8Lz5cbiAgICApXG4gIH1cbiAgcmV0dXJuIChudWxsKVxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6Ii9Vc2Vycy9wZXRyaXJvdXRhbWFhL0lkZWFQcm9qZWN0cy9GdWxsIFN0YWNrL3drNVRhc2tzL2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gifQ==