import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9924978"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e9924978"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import LoggedIn from "/src/components/LoggedIn.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import LogOutButton from "/src/components/LogOutButton.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import Notification from "/src/components/Notification.jsx";
import LoginForm from "/src/components/LoginForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [errorMessage, setErrorMessage] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBloglistUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const blogFormRef = useRef();
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBloglistUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setErrorMessage("wrong username or password");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const handleLogOut = async (event) => {
    event.preventDefault();
    setUser(null);
    blogService.setToken(null);
    window.localStorage.removeItem("loggedBloglistUser");
    console.log("logged out");
  };
  const addBlog = async (newBlog) => {
    blogFormRef.current.toggleVisibility();
    const returnedBlog = await blogService.createNewBlog(newBlog);
    console.log(returnedBlog);
    setBlogs(blogs.concat(returnedBlog));
    setTitle(returnedBlog.title);
    setAuthor(returnedBlog.author);
    setTimeout(() => {
      setAuthor("");
      setTitle("");
    }, 5e3);
  };
  const updateBlog = async (curBlog) => {
    const updatedBlog = {
      ...curBlog,
      ["likes"]: curBlog.likes + 1
    };
    console.log(updatedBlog);
    const blog = await blogService.updateBlog(updatedBlog.id, updatedBlog);
    console.log(blog);
    setBlogs((curBlogs) => curBlogs.map((curBlog2) => curBlog2.id === blog.id ? blog : curBlog2));
  };
  const deleteBlog = async (blog) => {
    console.log(blog.id);
    const confirm = window.confirm(`Delete this blog: ${blog.title} by ${blog.author}`);
    if (confirm) {
      await blogService.deleteBlog(blog.id);
      setBlogs(blogs.filter((curBlog) => curBlog.id !== blog.id));
    }
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
        lineNumber: 91,
        columnNumber: 9
      }, this),
      errorMessage ? /* @__PURE__ */ jsxDEV("p", { children: errorMessage }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
        lineNumber: 92,
        columnNumber: 25
      }, this) : null,
      /* @__PURE__ */ jsxDEV(LoginForm, { username, password, handleLogin, setPassword, setUsername }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
        lineNumber: 93,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
      lineNumber: 90,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
      lineNumber: 97,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { title, author }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
      lineNumber: 98,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      display: "flex",
      justifyContent: "left"
    }, children: [
      /* @__PURE__ */ jsxDEV(LoggedIn, { userName: user.name }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(LogOutButton, { handleLogOut }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "New blogpost", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
      lineNumber: 107,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
      lineNumber: 106,
      columnNumber: 7
    }, this),
    blogs.sort((a, b) => b.likes - a.likes).map((blog) => {
      return /* @__PURE__ */ jsxDEV(Blog, { blog, updateBlog: () => updateBlog(blog), deleteBlog: () => deleteBlog(blog), curUser: user }, blog.id, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
        lineNumber: 110,
        columnNumber: 14
      }, this);
    })
  ] }, void 0, true, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx",
    lineNumber: 96,
    columnNumber: 10
  }, this);
};
_s(App, "oG9dPSs1Cg7hQE1BhtbIlSQPT7s=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQXZHUixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGVBQWU7QUFFdEIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJZixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0IsT0FBT0MsUUFBUSxJQUFJakIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2tCLFFBQVFDLFNBQVMsSUFBSW5CLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNvQixjQUFjQyxlQUFlLElBQUlyQixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDc0IsVUFBVUMsV0FBVyxJQUFJdkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3dCLFVBQVVDLFdBQVcsSUFBSXpCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUMwQixNQUFNQyxPQUFPLElBQUkzQixTQUFTLElBQUk7QUFFckNDLFlBQVUsTUFBTTtBQUNkSSxnQkFBWXVCLE9BQU8sRUFBRUMsS0FBS2YsWUFDeEJDLFNBQVVELE1BQU0sQ0FDbEI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMYixZQUFVLE1BQU07QUFDZCxVQUFNNkIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG9CQUFvQjtBQUN2RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTUosUUFBT1EsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q0gsY0FBUUQsS0FBSTtBQUNackIsa0JBQVkrQixTQUFTVixNQUFLVyxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGNBQWNwQyxPQUFPO0FBRTNCLFFBQU1xQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1mLFFBQU8sTUFBTXBCLGFBQWFvQyxNQUFNO0FBQUEsUUFDcENwQjtBQUFBQSxRQUFVRTtBQUFBQSxNQUNaLENBQUM7QUFDRE8sYUFBT0MsYUFBYVcsUUFDbEIsc0JBQXNCVCxLQUFLVSxVQUFVbEIsS0FBSSxDQUMzQztBQUNBckIsa0JBQVkrQixTQUFTVixNQUFLVyxLQUFLO0FBQy9CVixjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVNvQixXQUFXO0FBQ2xCeEIsc0JBQWdCLDRCQUE0QjtBQUM1Q3lCLGlCQUFXLE1BQU07QUFDZnpCLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEIsZUFBZSxPQUFPUCxVQUFVO0FBQ3BDQSxVQUFNQyxlQUFlO0FBQ3JCZCxZQUFRLElBQUk7QUFDWnRCLGdCQUFZK0IsU0FBUyxJQUFJO0FBQ3pCTCxXQUFPQyxhQUFhZ0IsV0FBVyxvQkFBb0I7QUFDbkRDLFlBQVFDLElBQUksWUFBWTtBQUFBLEVBQzFCO0FBRUEsUUFBTUMsVUFBVSxPQUFPQyxZQUFZO0FBQ2pDZCxnQkFBWWUsUUFBUUMsaUJBQWlCO0FBQ3JDLFVBQU1DLGVBQWUsTUFBTWxELFlBQVltRCxjQUFjSixPQUFPO0FBQzVESCxZQUFRQyxJQUFJSyxZQUFZO0FBQ3hCeEMsYUFBU0QsTUFBTTJDLE9BQU9GLFlBQVksQ0FBQztBQUNuQ3RDLGFBQVNzQyxhQUFhdkMsS0FBSztBQUMzQkcsY0FBVW9DLGFBQWFyQyxNQUFNO0FBQzdCNEIsZUFBVyxNQUFNO0FBQ2YzQixnQkFBVSxFQUFFO0FBQ1pGLGVBQVMsRUFBRTtBQUFBLElBQ2IsR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUVBLFFBQU15QyxhQUFhLE9BQU9DLFlBQVk7QUFDcEMsVUFBTUMsY0FBYztBQUFBLE1BQ2xCLEdBQUdEO0FBQUFBLE1BQ0gsQ0FBQyxPQUFPLEdBQUdBLFFBQVFFLFFBQVE7QUFBQSxJQUM3QjtBQUNBWixZQUFRQyxJQUFJVSxXQUFXO0FBQ3ZCLFVBQU1FLE9BQU8sTUFBTXpELFlBQVlxRCxXQUFXRSxZQUFZRyxJQUFJSCxXQUFXO0FBQ3JFWCxZQUFRQyxJQUFJWSxJQUFJO0FBQ2hCL0MsYUFBU2lELGNBQVlBLFNBQVNDLElBQUlOLGNBQVdBLFNBQVFJLE9BQU9ELEtBQUtDLEtBQUtELE9BQU9ILFFBQU8sQ0FBQztBQUFBLEVBQ3ZGO0FBRUEsUUFBTU8sYUFBYSxPQUFPSixTQUFTO0FBQ2pDYixZQUFRQyxJQUFJWSxLQUFLQyxFQUFFO0FBQ25CLFVBQU1JLFVBQVVwQyxPQUFPb0MsUUFBUyxxQkFBb0JMLEtBQUs5QyxLQUFNLE9BQU04QyxLQUFLNUMsTUFBTyxFQUFDO0FBQ2xGLFFBQUlpRCxTQUFTO0FBQ1gsWUFBTTlELFlBQVk2RCxXQUFXSixLQUFLQyxFQUFFO0FBQ3BDaEQsZUFBU0QsTUFBTXNELE9BQU9ULGFBQVdBLFFBQVFJLE9BQU9ELEtBQUtDLEVBQUUsQ0FBQztBQUFBLElBQzFEO0FBQUEsRUFDRjtBQUVBLE1BQUlyQyxTQUFTLE1BQU07QUFDakIsV0FDRSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDeEJOLGVBQWUsdUJBQUMsT0FBR0EsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixJQUFPO0FBQUEsTUFDeEMsdUJBQUMsYUFDQyxVQUNBLFVBQ0EsYUFDQSxhQUNBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUsyQjtBQUFBLFNBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLEVBRUo7QUFDQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsZ0JBQWEsT0FBYyxVQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsSUFDM0MsdUJBQUMsU0FBSSxPQUFPO0FBQUEsTUFBRWlELFNBQVM7QUFBQSxNQUFRQyxnQkFBZ0I7QUFBQSxJQUFPLEdBQ3BEO0FBQUEsNkJBQUMsWUFBUyxVQUFVNUMsS0FBSzZDLFFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUM5Qix1QkFBQyxnQkFBYSxnQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxhQUFVLGFBQVksZ0JBQWUsS0FBS2pDLGFBQ3pDLGlDQUFDLFlBQVMsWUFBWWEsV0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QixLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDckMsTUFBTTBELEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRWIsUUFBUVksRUFBRVosS0FBSyxFQUFFSSxJQUFJSCxVQUFRO0FBQ25ELGFBQVEsdUJBQUMsUUFFUCxNQUNBLFlBQVksTUFBTUosV0FBV0ksSUFBSSxHQUNqQyxZQUFZLE1BQU1JLFdBQVdKLElBQUksR0FDakMsU0FBU3BDLFFBSkpvQyxLQUFLQyxJQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLUTtBQUFBLElBR2xCLENBQUM7QUFBQSxPQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBO0FBRUo7QUFBQ2xELEdBL0hLRCxLQUFHO0FBQUErRCxLQUFIL0Q7QUFpSU4sZUFBZUE7QUFBRyxJQUFBK0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsIkxvZ2dlZEluIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJMb2dPdXRCdXR0b24iLCJCbG9nRm9ybSIsIk5vdGlmaWNhdGlvbiIsIkxvZ2luRm9ybSIsIlRvZ2dsYWJsZSIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInRpdGxlIiwic2V0VGl0bGUiLCJhdXRob3IiLCJzZXRBdXRob3IiLCJlcnJvck1lc3NhZ2UiLCJzZXRFcnJvck1lc3NhZ2UiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwiZ2V0QWxsIiwidGhlbiIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJibG9nRm9ybVJlZiIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImV4Y2VwdGlvbiIsInNldFRpbWVvdXQiLCJoYW5kbGVMb2dPdXQiLCJyZW1vdmVJdGVtIiwiY29uc29sZSIsImxvZyIsImFkZEJsb2ciLCJuZXdCbG9nIiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJyZXR1cm5lZEJsb2ciLCJjcmVhdGVOZXdCbG9nIiwiY29uY2F0IiwidXBkYXRlQmxvZyIsImN1ckJsb2ciLCJ1cGRhdGVkQmxvZyIsImxpa2VzIiwiYmxvZyIsImlkIiwiY3VyQmxvZ3MiLCJtYXAiLCJkZWxldGVCbG9nIiwiY29uZmlybSIsImZpbHRlciIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsIm5hbWUiLCJzb3J0IiwiYSIsImIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBMb2dnZWRJbiBmcm9tICcuL2NvbXBvbmVudHMvTG9nZ2VkSW4nXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcbmltcG9ydCBMb2dPdXRCdXR0b24gZnJvbSAnLi9jb21wb25lbnRzL0xvZ091dEJ1dHRvbidcbmltcG9ydCBCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQmxvZ0Zvcm0nXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXG5pbXBvcnQgTG9naW5Gb3JtIGZyb20gJy4vY29tcG9uZW50cy9Mb2dpbkZvcm0nXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oYmxvZ3MgPT5cbiAgICAgIHNldEJsb2dzKCBibG9ncyApXG4gICAgKVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRCbG9nbGlzdFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKVxuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oe1xuICAgICAgICB1c2VybmFtZSwgcGFzc3dvcmQsXG4gICAgICB9KVxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAnbG9nZ2VkQmxvZ2xpc3RVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICAgIClcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCd3cm9uZyB1c2VybmFtZSBvciBwYXNzd29yZCcpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ091dCA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBzZXRVc2VyKG51bGwpXG4gICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obnVsbClcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2xvZ2dlZEJsb2dsaXN0VXNlcicpXG4gICAgY29uc29sZS5sb2coJ2xvZ2dlZCBvdXQnKVxuICB9XG5cbiAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChuZXdCbG9nKSA9PiB7XG4gICAgYmxvZ0Zvcm1SZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcbiAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGVOZXdCbG9nKG5ld0Jsb2cpXG4gICAgY29uc29sZS5sb2cocmV0dXJuZWRCbG9nKVxuICAgIHNldEJsb2dzKGJsb2dzLmNvbmNhdChyZXR1cm5lZEJsb2cpKVxuICAgIHNldFRpdGxlKHJldHVybmVkQmxvZy50aXRsZSlcbiAgICBzZXRBdXRob3IocmV0dXJuZWRCbG9nLmF1dGhvcilcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldEF1dGhvcignJylcbiAgICAgIHNldFRpdGxlKCcnKVxuICAgIH0sIDUwMDApXG4gIH1cblxuICBjb25zdCB1cGRhdGVCbG9nID0gYXN5bmMgKGN1ckJsb2cpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IHtcbiAgICAgIC4uLmN1ckJsb2csXG4gICAgICBbJ2xpa2VzJ106IGN1ckJsb2cubGlrZXMgKyAxXG4gICAgfVxuICAgIGNvbnNvbGUubG9nKHVwZGF0ZWRCbG9nKVxuICAgIGNvbnN0IGJsb2cgPSBhd2FpdCBibG9nU2VydmljZS51cGRhdGVCbG9nKHVwZGF0ZWRCbG9nLmlkLCB1cGRhdGVkQmxvZylcbiAgICBjb25zb2xlLmxvZyhibG9nKVxuICAgIHNldEJsb2dzKGN1ckJsb2dzID0+IGN1ckJsb2dzLm1hcChjdXJCbG9nID0+IGN1ckJsb2cuaWQgPT09IGJsb2cuaWQgPyBibG9nIDogY3VyQmxvZykpXG4gIH1cblxuICBjb25zdCBkZWxldGVCbG9nID0gYXN5bmMgKGJsb2cpID0+IHtcbiAgICBjb25zb2xlLmxvZyhibG9nLmlkKVxuICAgIGNvbnN0IGNvbmZpcm0gPSB3aW5kb3cuY29uZmlybShgRGVsZXRlIHRoaXMgYmxvZzogJHtibG9nLnRpdGxlfSBieSAke2Jsb2cuYXV0aG9yfWApXG4gICAgaWYgKGNvbmZpcm0pIHtcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLmRlbGV0ZUJsb2coYmxvZy5pZClcbiAgICAgIHNldEJsb2dzKGJsb2dzLmZpbHRlcihjdXJCbG9nID0+IGN1ckJsb2cuaWQgIT09IGJsb2cuaWQpKVxuICAgIH1cbiAgfVxuXG4gIGlmICh1c2VyID09PSBudWxsKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMj5Mb2cgaW4gdG8gYXBwbGljYXRpb248L2gyPlxuICAgICAgICB7ZXJyb3JNZXNzYWdlID8gPHA+e2Vycm9yTWVzc2FnZX08L3A+IDogbnVsbH1cbiAgICAgICAgPExvZ2luRm9ybVxuICAgICAgICAgIHVzZXJuYW1lPXt1c2VybmFtZX1cbiAgICAgICAgICBwYXNzd29yZD17cGFzc3dvcmR9XG4gICAgICAgICAgaGFuZGxlTG9naW49e2hhbmRsZUxvZ2lufVxuICAgICAgICAgIHNldFBhc3N3b3JkPXtzZXRQYXNzd29yZH1cbiAgICAgICAgICBzZXRVc2VybmFtZT17c2V0VXNlcm5hbWV9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkJsb2dzPC9oMj5cbiAgICAgIDxOb3RpZmljYXRpb24gdGl0bGU9e3RpdGxlfSBhdXRob3I9e2F1dGhvcn0gLz5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ2xlZnQnIH19PlxuICAgICAgICA8TG9nZ2VkSW4gdXNlck5hbWU9e3VzZXIubmFtZX0gLz5cbiAgICAgICAgPExvZ091dEJ1dHRvbiBoYW5kbGVMb2dPdXQ9e2hhbmRsZUxvZ091dH0gLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cIk5ldyBibG9ncG9zdFwiIHJlZj17YmxvZ0Zvcm1SZWZ9PlxuICAgICAgICA8QmxvZ0Zvcm0gY3JlYXRlQmxvZz17YWRkQmxvZ30vPlxuICAgICAgPC9Ub2dnbGFibGU+XG4gICAgICB7YmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpLm1hcChibG9nID0+IHtcbiAgICAgICAgcmV0dXJuICg8QmxvZyBcbiAgICAgICAgICBrZXk9e2Jsb2cuaWR9IFxuICAgICAgICAgIGJsb2c9e2Jsb2d9IFxuICAgICAgICAgIHVwZGF0ZUJsb2c9eygpID0+IHVwZGF0ZUJsb2coYmxvZyl9IFxuICAgICAgICAgIGRlbGV0ZUJsb2c9eygpID0+IGRlbGV0ZUJsb2coYmxvZyl9XG4gICAgICAgICAgY3VyVXNlcj17dXNlcn1cbiAgICAgICAgICAvPlxuICAgICAgICApXG4gICAgICB9KX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9Vc2Vycy9wZXRyaXJvdXRhbWFhL0lkZWFQcm9qZWN0cy9GdWxsIFN0YWNrL3drNVRhc2tzL2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=