import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9924978"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e9924978"; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({
  blog,
  updateBlog,
  deleteBlog,
  curUser
}) => {
  _s();
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const [visible, setVisible] = useState(false);
  if (!visible) {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { placeholder: "blogTitle", className: "blog", style: blogStyle, children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setVisible(!visible), children: "view" }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 21,
        columnNumber: 38
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 20,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 19,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { placeholder: "allVisible", style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setVisible(!visible), children: "hide" }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 27,
        columnNumber: 41
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 27,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blog.url }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 28,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "likes ",
      blog.likes,
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: updateBlog, children: "like" }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 29,
        columnNumber: 33
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blog.user.name }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    curUser.name === blog.user.name ? /* @__PURE__ */ jsxDEV("button", { onClick: deleteBlog, children: "delete" }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 31,
      columnNumber: 44
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 26,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY00sbUJBRStCLGNBRi9COzs7Ozs7Ozs7Ozs7Ozs7OztBQWROLFNBQVNBLGdCQUFnQjtBQUV6QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBWUM7QUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFDMUQsUUFBTUMsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLEVBQ2hCO0FBQ0EsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlkLFNBQVMsS0FBSztBQUU1QyxNQUFJLENBQUNhLFNBQVM7QUFDWixXQUNFLG1DQUNFLGlDQUFDLFNBQUksYUFBWSxhQUFZLFdBQVUsUUFBTyxPQUFPTixXQUNsREw7QUFBQUEsV0FBS2E7QUFBQUEsTUFBTTtBQUFBLE1BQUViLEtBQUtjO0FBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBUyxNQUFNRixXQUFXLENBQUNELE9BQU8sR0FBRyxvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLFNBRDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUo7QUFDQSxTQUNFLG1DQUNFLGlDQUFDLFNBQUksYUFBWSxjQUFhLE9BQU9OLFdBQ25DO0FBQUEsMkJBQUMsU0FBS0w7QUFBQUEsV0FBS2E7QUFBQUEsTUFBTTtBQUFBLE1BQUViLEtBQUtjO0FBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBUyxNQUFNRixXQUFXLENBQUNELE9BQU8sR0FBRyxvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLFNBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEY7QUFBQSxJQUMxRix1QkFBQyxTQUFLWCxlQUFLZSxPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZTtBQUFBLElBQ2YsdUJBQUMsU0FBSTtBQUFBO0FBQUEsTUFBT2YsS0FBS2dCO0FBQUFBLE1BQU07QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBU2YsWUFBWSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLFNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0U7QUFBQSxJQUNsRSx1QkFBQyxTQUFLRCxlQUFLaUIsS0FBS0MsUUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3BCZixRQUFRZSxTQUFTbEIsS0FBS2lCLEtBQUtDLE9BQzFCLHVCQUFDLFlBQU8sU0FBU2hCLFlBQVksc0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUMsSUFDbkM7QUFBQSxPQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBQUNFLEdBaENLTCxNQUFJO0FBQUFvQixLQUFKcEI7QUFrQ04sZUFBZUE7QUFBSSxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZyIsImJsb2ciLCJ1cGRhdGVCbG9nIiwiZGVsZXRlQmxvZyIsImN1clVzZXIiLCJfcyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJ0aXRsZSIsImF1dGhvciIsInVybCIsImxpa2VzIiwidXNlciIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCB1cGRhdGVCbG9nLCBkZWxldGVCbG9nLCBjdXJVc2VyIH0pID0+IHtcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDVcbiAgfVxuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBpZiAoIXZpc2libGUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPD5cbiAgICAgICAgPGRpdiBwbGFjZWhvbGRlcj0nYmxvZ1RpdGxlJyBjbGFzc05hbWU9J2Jsb2cnIHN0eWxlPXtibG9nU3R5bGV9PlxuICAgICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9IDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0VmlzaWJsZSghdmlzaWJsZSl9PnZpZXc8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8Lz5cbiAgICApXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBwbGFjZWhvbGRlcj0nYWxsVmlzaWJsZScgc3R5bGU9e2Jsb2dTdHlsZX0+XG4gICAgICAgIDxkaXY+e2Jsb2cudGl0bGV9IHtibG9nLmF1dGhvcn0gPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRWaXNpYmxlKCF2aXNpYmxlKX0+aGlkZTwvYnV0dG9uPjwvZGl2PlxuICAgICAgICA8ZGl2PntibG9nLnVybH08L2Rpdj5cbiAgICAgICAgPGRpdj5saWtlcyB7YmxvZy5saWtlc30gPGJ1dHRvbiBvbkNsaWNrPXt1cGRhdGVCbG9nfT5saWtlPC9idXR0b24+PC9kaXY+XG4gICAgICAgIDxkaXY+e2Jsb2cudXNlci5uYW1lfTwvZGl2PlxuICAgICAgICB7Y3VyVXNlci5uYW1lID09PSBibG9nLnVzZXIubmFtZSBcbiAgICAgICAgPyA8YnV0dG9uIG9uQ2xpY2s9e2RlbGV0ZUJsb2d9PmRlbGV0ZTwvYnV0dG9uPlxuICAgICAgICA6IG51bGwgfVxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiL1VzZXJzL3BldHJpcm91dGFtYWEvSWRlYVByb2plY3RzL0Z1bGwgU3RhY2svd2s1VGFza3MvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==