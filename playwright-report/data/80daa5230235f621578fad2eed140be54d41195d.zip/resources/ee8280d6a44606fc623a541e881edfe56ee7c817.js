import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LogOutButton.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9924978"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LogOutButton.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const LogOutButton = ({
  handleLogOut
}) => {
  return /* @__PURE__ */ jsxDEV("button", { onClick: handleLogOut, children: "Logout" }, void 0, false, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LogOutButton.jsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
};
_c = LogOutButton;
export default LogOutButton;
var _c;
$RefreshReg$(_c, "LogOutButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LogOutButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBRUk7QUFGSixPQUFNQSxvQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFFQztBQUFhLE1BQU07QUFDekMsU0FDRSx1QkFBQyxZQUFPLFNBQVNBLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUM7QUFFekM7QUFBQ0MsS0FKS0Y7QUFNTixlQUFlQTtBQUFZLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMb2dPdXRCdXR0b24iLCJoYW5kbGVMb2dPdXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ091dEJ1dHRvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTG9nT3V0QnV0dG9uID0gKHsgaGFuZGxlTG9nT3V0IH0pID0+IHtcbiAgcmV0dXJuKFxuICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nT3V0fT5Mb2dvdXQ8L2J1dHRvbj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2dPdXRCdXR0b24iXSwiZmlsZSI6Ii9Vc2Vycy9wZXRyaXJvdXRhbWFhL0lkZWFQcm9qZWN0cy9GdWxsIFN0YWNrL3drNVRhc2tzL2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0xvZ091dEJ1dHRvbi5qc3gifQ==