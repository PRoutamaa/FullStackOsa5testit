import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9924978"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e9924978"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=e9924978"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [newBlog, setNewBlog] = useState({
    title: "",
    author: "",
    url: ""
  });
  const addBlog = (event) => {
    event.preventDefault();
    createBlog(newBlog);
    setNewBlog({
      title: "",
      author: "",
      url: ""
    });
  };
  const handleBlogChange = (event) => {
    event.preventDefault();
    const {
      name,
      value
    } = event.target;
    setNewBlog((currentValues) => ({
      ...currentValues,
      [name]: value
    }));
  };
  return /* @__PURE__ */ jsxDEV("form", { className: "form", onSubmit: addBlog, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create new blogpost" }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "title:",
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "title", type: "text", value: newBlog.title, name: "title", onChange: handleBlogChange }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "author:",
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "author", type: "text", name: "author", value: newBlog.author, onChange: handleBlogChange }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "url:",
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "url", type: "text", name: "url", value: newBlog.url, onChange: handleBlogChange }, void 0, false, {
        fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "create", children: "save" }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "K/tN8NRnJMKJ8njMUg+eQKPnUio=");
_c = BlogForm;
BlogForm.propTypes = {
  createBlog: PropTypes.func.isRequired
};
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCTixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxXQUFXQSxDQUFDO0FBQUEsRUFBRUM7QUFBVyxNQUFNO0FBQUFDLEtBQUE7QUFDbkMsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBQVM7QUFBQSxJQUFFTyxPQUFPO0FBQUEsSUFBSUMsUUFBUTtBQUFBLElBQUlDLEtBQUs7QUFBQSxFQUFHLENBQUM7QUFFekUsUUFBTUMsVUFBV0MsV0FBVTtBQUN6QkEsVUFBTUMsZUFBZTtBQUNyQlQsZUFBV0UsT0FBTztBQUVsQkMsZUFBVztBQUFBLE1BQUVDLE9BQU87QUFBQSxNQUFJQyxRQUFRO0FBQUEsTUFBSUMsS0FBSztBQUFBLElBQUcsQ0FBQztBQUFBLEVBQy9DO0FBRUEsUUFBTUksbUJBQW9CRixXQUFVO0FBQ2xDQSxVQUFNQyxlQUFlO0FBQ3JCLFVBQU07QUFBQSxNQUFFRTtBQUFBQSxNQUFNQztBQUFBQSxJQUFNLElBQUlKLE1BQU1LO0FBQzlCVixlQUFZVyxvQkFBbUI7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNILENBQUNILElBQUksR0FBR0M7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxXQUFVLFFBQU8sVUFBVUwsU0FDL0I7QUFBQSwyQkFBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxJQUN2Qix1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQ0MsZUFBWSxTQUNaLE1BQUssUUFDTCxPQUFPTCxRQUFRRSxPQUNmLE1BQUssU0FDTCxVQUFVTSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzZCO0FBQUEsU0FQL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQ0MsZUFBWSxVQUNaLE1BQUssUUFDTCxNQUFLLFVBQ0wsT0FBT1IsUUFBUUcsUUFDZixVQUFVSyxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzZCO0FBQUEsU0FQL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGLHVCQUFDLFdBQ0MsZUFBWSxPQUNaLE1BQUssUUFDTCxNQUFLLE9BQ0wsT0FBT1IsUUFBUUksS0FDZixVQUFVSSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSzZCO0FBQUEsU0FQL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLE9BaEM1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ1QsR0F2REtGLFVBQVE7QUFBQWdCLEtBQVJoQjtBQXlETkEsU0FBU2lCLFlBQVk7QUFBQSxFQUNuQmhCLFlBQVlGLFVBQVVtQixLQUFLQztBQUM3QjtBQUVBLGVBQWVuQjtBQUFRLElBQUFnQjtBQUFBSSxhQUFBSixJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJQcm9wVHlwZXMiLCJCbG9nRm9ybSIsImNyZWF0ZUJsb2ciLCJfcyIsIm5ld0Jsb2ciLCJzZXROZXdCbG9nIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJhZGRCbG9nIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZUJsb2dDaGFuZ2UiLCJuYW1lIiwidmFsdWUiLCJ0YXJnZXQiLCJjdXJyZW50VmFsdWVzIiwiX2MiLCJwcm9wVHlwZXMiLCJmdW5jIiwiaXNSZXF1aXJlZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuXG5jb25zdCBCbG9nRm9ybSA9ICh7IGNyZWF0ZUJsb2cgfSkgPT4ge1xuICBjb25zdCBbbmV3QmxvZywgc2V0TmV3QmxvZ10gPSB1c2VTdGF0ZSh7IHRpdGxlOiAnJywgYXV0aG9yOiAnJywgdXJsOiAnJyB9KVxuXG4gIGNvbnN0IGFkZEJsb2cgPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgY3JlYXRlQmxvZyhuZXdCbG9nKVxuXG4gICAgc2V0TmV3QmxvZyh7IHRpdGxlOiAnJywgYXV0aG9yOiAnJywgdXJsOiAnJyB9KVxuICB9XG5cbiAgY29uc3QgaGFuZGxlQmxvZ0NoYW5nZSA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBldmVudC50YXJnZXRcbiAgICBzZXROZXdCbG9nKChjdXJyZW50VmFsdWVzKSA9PiAoe1xuICAgICAgLi4uY3VycmVudFZhbHVlcyxcbiAgICAgIFtuYW1lXTogdmFsdWUsXG4gICAgfSkpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxmb3JtIGNsYXNzTmFtZT0nZm9ybScgb25TdWJtaXQ9e2FkZEJsb2d9PlxuICAgICAgPGgyPkNyZWF0ZSBuZXcgYmxvZ3Bvc3Q8L2gyPlxuICAgICAgPGRpdj5cbiAgICAgIHRpdGxlOlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBkYXRhLXRlc3RpZD0ndGl0bGUnXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXtuZXdCbG9nLnRpdGxlfVxuICAgICAgICAgIG5hbWU9XCJ0aXRsZVwiXG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUJsb2dDaGFuZ2V9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICBhdXRob3I6XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGRhdGEtdGVzdGlkPSdhdXRob3InXG4gICAgICAgICAgdHlwZT0ndGV4dCdcbiAgICAgICAgICBuYW1lPVwiYXV0aG9yXCJcbiAgICAgICAgICB2YWx1ZT17bmV3QmxvZy5hdXRob3J9XG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUJsb2dDaGFuZ2V9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICB1cmw6XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGRhdGEtdGVzdGlkPSd1cmwnXG4gICAgICAgICAgdHlwZT0ndGV4dCdcbiAgICAgICAgICBuYW1lPVwidXJsXCJcbiAgICAgICAgICB2YWx1ZT17bmV3QmxvZy51cmx9XG4gICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUJsb2dDaGFuZ2V9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gdHlwZT1cImNyZWF0ZVwiPnNhdmU8L2J1dHRvbj5cbiAgICA8L2Zvcm0+XG4gIClcbn1cblxuQmxvZ0Zvcm0ucHJvcFR5cGVzID0ge1xuICBjcmVhdGVCbG9nOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dGb3JtIl0sImZpbGUiOiIvVXNlcnMvcGV0cmlyb3V0YW1hYS9JZGVhUHJvamVjdHMvRnVsbCBTdGFjay93azVUYXNrcy9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nRm9ybS5qc3gifQ==