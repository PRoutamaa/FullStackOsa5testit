import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9924978"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const LoginForm = ({
  username,
  password,
  handleLogin,
  setPassword,
  setUsername
}) => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
  /* @__PURE__ */ jsxDEV("div", { children: [
    "username",
    /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: username, name: "Username", onChange: ({
      target
    }) => setUsername(target.value) }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 10,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 8,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("div", { children: [
    "password",
    /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, name: "Password", onChange: ({
      target
    }) => setPassword(target.value) }, void 0, false, {
      fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 14,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
    fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 20,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx",
  lineNumber: 7,
  columnNumber: 7
}, this);
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/petriroutamaa/IdeaProjects/Full Stack/wk5Tasks/bloglist-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSU07QUFKTixPQUFNQSxvQkFBYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQUVDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQWFDO0FBQUFBLEVBQWFDO0FBQVksTUFDN0UsdUJBQUMsVUFBSyxVQUFVRixhQUNkO0FBQUEseUJBQUMsU0FBRztBQUFBO0FBQUEsSUFFRix1QkFBQyxXQUNDLGVBQVksWUFDWixNQUFLLFFBQ0wsT0FBT0YsVUFDUCxNQUFLLFlBQ0wsVUFBVSxDQUFDO0FBQUEsTUFBRUs7QUFBQUEsSUFBTyxNQUFNRCxZQUFZQyxPQUFPQyxLQUFLLEtBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLc0Q7QUFBQSxPQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFBQSxFQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLElBRUYsdUJBQUMsV0FDQyxlQUFZLFlBQ1osTUFBSyxZQUNMLE9BQU9MLFVBQ1AsTUFBSyxZQUNMLFVBQVUsQ0FBQztBQUFBLE1BQUVJO0FBQUFBLElBQU8sTUFBTUYsWUFBWUUsT0FBT0MsS0FBSyxLQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3NEO0FBQUEsT0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBQUEsRUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQjtBQUFBLEtBckI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9Bc0JBO0FBQ0RDLEtBeEJLUjtBQTBCTixlQUFlQTtBQUFTLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMb2dpbkZvcm0iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiaGFuZGxlTG9naW4iLCJzZXRQYXNzd29yZCIsInNldFVzZXJuYW1lIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTG9naW5Gb3JtID0gKHsgdXNlcm5hbWUsIHBhc3N3b3JkLCBoYW5kbGVMb2dpbiwgc2V0UGFzc3dvcmQsIHNldFVzZXJuYW1lIH0pID0+IChcbiAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUxvZ2lufT5cbiAgICA8ZGl2PlxuICAgICAgICB1c2VybmFtZVxuICAgICAgPGlucHV0XG4gICAgICAgIGRhdGEtdGVzdGlkPSd1c2VybmFtZSdcbiAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgIG5hbWU9XCJVc2VybmFtZVwiXG4gICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICAgPGRpdj5cbiAgICAgICAgcGFzc3dvcmRcbiAgICAgIDxpbnB1dFxuICAgICAgICBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnXG4gICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgbmFtZT1cIlBhc3N3b3JkXCJcbiAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5sb2dpbjwvYnV0dG9uPlxuICA8L2Zvcm0+XG4pXG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luRm9ybSJdLCJmaWxlIjoiL1VzZXJzL3BldHJpcm91dGFtYWEvSWRlYVByb2plY3RzL0Z1bGwgU3RhY2svd2s1VGFza3MvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5Gb3JtLmpzeCJ9